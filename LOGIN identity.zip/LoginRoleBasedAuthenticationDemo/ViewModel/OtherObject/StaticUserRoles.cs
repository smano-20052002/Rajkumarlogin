﻿namespace LoginRoleBasedAuthenticationDemo.ViewModel.OtherObject
{
    public static class StaticUserRoles
    {
        public const string OWNER = "OWNER";
        public const string ADMIN = "ADMIN";
        public const string USER = "USER";
    }
}
